import React from 'react';
import { Drawer, List, ListItemButton, ListItemIcon, ListItemText, Toolbar, useMediaQuery, useTheme, Box } from '@mui/material';
import { useLocation, useNavigate } from 'react-router-dom';
import DashboardIcon from '@mui/icons-material/Dashboard';
import PaymentsIcon from '@mui/icons-material/Payments';
import CategoryIcon from '@mui/icons-material/Category';
import AccountBalanceIcon from '@mui/icons-material/AccountBalance';
import PieChartIcon from '@mui/icons-material/PieChart';
import SavingsIcon from '@mui/icons-material/Savings';
import TrendingUpIcon from '@mui/icons-material/TrendingUp';
import AccountBalanceWalletIcon from '@mui/icons-material/AccountBalanceWallet';

const menu = [
  { label: 'Dashboard', icon: <DashboardIcon />, path: '/', color: '#6366f1' },
  { label: 'Transactions', icon: <PaymentsIcon />, path: '/transactions', color: '#10b981' },
  { label: 'Categories', icon: <CategoryIcon />, path: '/categories', color: '#f59e0b' },
  { label: 'Accounts', icon: <AccountBalanceIcon />, path: '/accounts', color: '#3b82f6' },
  { label: 'Budgets', icon: <SavingsIcon />, path: '/budgets', color: '#ec4899' },
  { label: 'Goals', icon: <SavingsIcon />, path: '/goals', color: '#f472b6' },
  { label: 'Investments', icon: <PieChartIcon />, path: '/investments', color: '#fbbf24' },
  { label: 'Stocks', icon: <TrendingUpIcon />, path: '/stocks', color: '#22c55e' },
  { label: 'Salary Planner', icon: <AccountBalanceWalletIcon />, path: '/salary-planner', color: '#a855f7' },
  { label: 'Analytics', icon: <PieChartIcon />, path: '/analytics', color: '#8b5cf6' },
];

interface SidebarProps {
  drawerWidth: number;
  mobileOpen: boolean;
  handleDrawerToggle: () => void;
}

const Sidebar: React.FC<SidebarProps> = ({ drawerWidth, mobileOpen, handleDrawerToggle }) => {
  const location = useLocation();
  const navigate = useNavigate();
  const theme = useTheme();
  const isMobile = useMediaQuery(theme.breakpoints.down('md'));

  const handleNavigation = (path: string) => {
    navigate(path);
    if (isMobile) {
      handleDrawerToggle();
    }
  };

  const drawerContent = (
    <Box sx={{ height: '100%', display: 'flex', flexDirection: 'column' }}>
      <Toolbar sx={{
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        borderBottom: '1px solid rgba(255, 255, 255, 0.12)',
      }}>
        <Box sx={{
          fontSize: '1.25rem',
          fontWeight: 700,
          background: 'linear-gradient(135deg, #6366f1 0%, #ec4899 100%)',
          WebkitBackgroundClip: 'text',
          WebkitTextFillColor: 'transparent',
          letterSpacing: '0.5px',
        }}>
          Money Manager
        </Box>
      </Toolbar>
      <List sx={{ pt: 2, px: 1 }}>
        {menu.map((item) => (
          <ListItemButton
            key={item.path}
            selected={location.pathname === item.path}
            onClick={() => handleNavigation(item.path)}
            sx={{
              mb: 0.5,
              borderRadius: 2,
              transition: 'all 0.3s cubic-bezier(0.4, 0, 0.2, 1)',
              position: 'relative',
              overflow: 'hidden',
              '&::before': {
                content: '""',
                position: 'absolute',
                top: 0,
                left: 0,
                right: 0,
                bottom: 0,
                background: `linear-gradient(135deg, ${item.color}30 0%, ${item.color}10 100%)`,
                opacity: 0,
                transition: 'opacity 0.3s ease',
              },
              '&:hover': {
                backgroundColor: 'rgba(255, 255, 255, 0.1)',
                transform: 'translateX(8px)',
                '&::before': {
                  opacity: 1,
                },
              },
              '&.Mui-selected': {
                backgroundColor: 'rgba(255, 255, 255, 0.15)',
                '&::before': {
                  opacity: 1,
                },
                '&:hover': {
                  backgroundColor: 'rgba(255, 255, 255, 0.2)',
                },
              },
            }}
          >
            <ListItemIcon sx={{
              color: item.color,
              minWidth: 40,
              transition: 'all 0.3s ease',
              filter: `drop-shadow(0 0 8px ${item.color}80)`,
              '&:hover': {
                transform: 'scale(1.2) rotate(5deg)',
                filter: `drop-shadow(0 0 12px ${item.color})`,
              },
            }}>
              {item.icon}
            </ListItemIcon>
            <ListItemText
              primary={item.label}
              sx={{
                '& .MuiListItemText-primary': {
                  color: 'white',
                  fontWeight: location.pathname === item.path ? 600 : 400,
                },
              }}
            />
          </ListItemButton>
        ))}
      </List>
    </Box>
  );

  return (
    <>
      {/* Mobile drawer */}
      <Drawer
        variant="temporary"
        open={mobileOpen}
        onClose={handleDrawerToggle}
        ModalProps={{
          keepMounted: true,
        }}
        sx={{
          display: { xs: 'block', md: 'none' },
          '& .MuiDrawer-paper': {
            width: drawerWidth,
            boxSizing: 'border-box',
          },
        }}
      >
        {drawerContent}
      </Drawer>
      {/* Desktop drawer */}
      <Drawer
        variant="permanent"
        sx={{
          display: { xs: 'none', md: 'block' },
          width: drawerWidth,
          flexShrink: 0,
          '& .MuiDrawer-paper': {
            width: drawerWidth,
            boxSizing: 'border-box',
          },
        }}
      >
        {drawerContent}
      </Drawer>
    </>
  );
};

export default Sidebar;
