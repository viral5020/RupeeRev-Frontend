import React from 'react';
import { Card, CardContent, Typography, Chip, Stack, IconButton, Tooltip } from '@mui/material';
import DeleteIcon from '@mui/icons-material/Delete';
import EditIcon from '@mui/icons-material/Edit';
import { Transaction } from '../../types';
import { formatCurrency, formatDate } from '../../utils/format';
import AttachmentPreview from '../attachments/AttachmentPreview';

interface Props {
  transaction: Transaction;
  onEdit: (transaction: Transaction) => void;
  onDelete: (transaction: Transaction) => void;
}

const TransactionCard: React.FC<Props> = ({ transaction, onEdit, onDelete }) => {
  const isIncome = transaction.type === 'income';
  return (
    <Card sx={{ borderLeft: `4px solid ${isIncome ? '#22c55e' : '#ef4444'}` }}>
      <CardContent>
        <Stack direction="row" justifyContent="space-between" alignItems="center">
          <div>
            <Typography variant="h6">{transaction.title}</Typography>
            <Typography variant="body2" color="text.secondary">
              {transaction.category.name} • {transaction.account.name}
            </Typography>
          </div>
          <Stack direction="row" spacing={1}>
            <Tooltip title="Edit">
              <IconButton onClick={() => onEdit(transaction)}>
                <EditIcon />
              </IconButton>
            </Tooltip>
            <Tooltip title="Delete">
              <IconButton onClick={() => onDelete(transaction)}>
                <DeleteIcon />
              </IconButton>
            </Tooltip>
          </Stack>
        </Stack>
        <Typography variant="h5" sx={{ mt: 1, color: isIncome ? 'success.main' : 'error.main' }}>
          {isIncome ? '+' : '-'}
          {formatCurrency(transaction.amount, transaction.account.currency)}
        </Typography>
        <Typography variant="caption" color="text.secondary">
          {formatDate(transaction.date)}
        </Typography>
        <Stack direction="row" spacing={1} sx={{ mt: 1 }}>
          {transaction.tags?.map((tag) => (
            <Chip key={tag} label={tag} size="small" />
          ))}
        </Stack>
        <AttachmentPreview attachments={transaction.attachments} />
      </CardContent>
    </Card>
  );
};

export default TransactionCard;

