import React from 'react';
import { Box, Button, MenuItem, TextField } from '@mui/material';
import DateRangePicker from '../common/DateRangePicker';
import { useFilters } from '../../context/FilterContext';
import CategorySelect from '../common/CategorySelect';
import AccountSelector from '../common/AccountSelector';

const TransactionFilters: React.FC = () => {
  const { filters, setFilters, reset } = useFilters();
  return (
    <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 2, mb: 3 }}>
      <TextField label="Search" value={filters.search ?? ''} onChange={(event) => setFilters({ search: event.target.value })} size="small" />
      <TextField
        select
        label="Type"
        value={filters.type ?? ''}
        onChange={(event) => setFilters({ type: (event.target.value || undefined) as 'income' | 'expense' | undefined })}
        size="small"
        sx={{ minWidth: 160 }}
      >
        <MenuItem value="">All</MenuItem>
        <MenuItem value="income">Income</MenuItem>
        <MenuItem value="expense">Expense</MenuItem>
      </TextField>
      <Box sx={{ minWidth: 200 }}>
        <CategorySelect value={filters.category} onChange={(value) => setFilters({ category: value })} type={filters.type ?? ('all' as const)} label="Category" />
      </Box>
      <Box sx={{ minWidth: 200 }}>
        <AccountSelector value={filters.account} onChange={(value) => setFilters({ account: value })} />
      </Box>
      <DateRangePicker
        startDate={filters.startDate}
        endDate={filters.endDate}
        onChange={({ startDate, endDate }) => setFilters({ startDate, endDate })}
      />
      <Button variant="outlined" onClick={reset}>
        Reset
      </Button>
    </Box>
  );
};

export default TransactionFilters;

