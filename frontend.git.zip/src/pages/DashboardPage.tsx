import React from 'react';
import { Grid, Paper, Typography, Button, Stack } from '@mui/material';
import { useMonthlyStats, useCategoryStats } from '../hooks/useStats';
import { useBudget } from '../hooks/useBudget';
import { formatCurrency } from '../utils/format';
import CategoryPieChart from '../components/analytics/CategoryPieChart';
import BudgetProgress from '../components/common/BudgetProgress';
import PageHeader from '../components/common/PageHeader';
import { exportCsv, exportExcel, exportPdf } from '../services/exportService';

const DashboardPage: React.FC = () => {
  const now = new Date();
  const { data: monthly } = useMonthlyStats(now.getMonth() + 1, now.getFullYear());
  const { data: categories } = useCategoryStats({ startDate: undefined, endDate: undefined });
  const { data: budget } = useBudget(now.getMonth() + 1, now.getFullYear());

  return (
    <div>
      <PageHeader title="Dashboard" />
      <Grid container spacing={2}>
        <Grid item xs={12} md={9}>
          <Paper sx={{
            p: { xs: 2, sm: 3 },
            background: 'linear-gradient(135deg, #ffffff 0%, #fef3c7 100%)',
            border: '2px solid #fde68a',
            transition: 'transform 0.2s ease, box-shadow 0.2s ease',
            '&:hover': {
              transform: 'translateY(-4px)',
              boxShadow: '0 12px 24px rgba(245, 158, 11, 0.2)',
            },
          }}>
            <Typography variant="h6" sx={{
              background: 'linear-gradient(135deg, #f59e0b 0%, #d97706 100%)',
              WebkitBackgroundClip: 'text',
              WebkitTextFillColor: 'transparent',
              fontWeight: 700,
              mb: 2,
            }}>
              Category Spend
            </Typography>
            <CategoryPieChart data={categories || []} />
          </Paper>
        </Grid>
        <Grid item xs={12} md={3}>
          <Paper sx={{
            p: { xs: 2, sm: 3 },
            background: 'linear-gradient(135deg, #ffffff 0%, #f0f9ff 100%)',
            border: '2px solid #e0f2fe',
            transition: 'transform 0.2s ease, box-shadow 0.2s ease',
            '&:hover': {
              transform: 'translateY(-4px)',
              boxShadow: '0 12px 24px rgba(59, 130, 246, 0.15)',
            },
          }}>
            <Typography variant="subtitle2" sx={{ color: '#64748b', mb: 1 }}>Total Income</Typography>
            <Typography variant="h4" sx={{
              background: 'linear-gradient(135deg, #10b981 0%, #059669 100%)',
              WebkitBackgroundClip: 'text',
              WebkitTextFillColor: 'transparent',
              fontWeight: 700,
            }}>
              {formatCurrency(monthly?.totalIncome || 0)}
            </Typography>
            <Typography variant="subtitle2" sx={{ mt: 3, color: '#64748b', mb: 1 }}>
              Total Expenses
            </Typography>
            <Typography variant="h4" sx={{
              background: 'linear-gradient(135deg, #ef4444 0%, #dc2626 100%)',
              WebkitBackgroundClip: 'text',
              WebkitTextFillColor: 'transparent',
              fontWeight: 700,
            }}>
              {formatCurrency(monthly?.totalExpense || 0)}
            </Typography>
            <Typography variant="subtitle2" sx={{ mt: 3, color: '#64748b', mb: 1 }}>
              Savings
            </Typography>
            <Typography variant="h4" sx={{
              background: 'linear-gradient(135deg, #6366f1 0%, #8b5cf6 100%)',
              WebkitBackgroundClip: 'text',
              WebkitTextFillColor: 'transparent',
              fontWeight: 700,
            }}>
              {formatCurrency(monthly?.savings || 0)}
            </Typography>
          </Paper>
        </Grid>
        <Grid item xs={12} md={8}>
          <Paper sx={{
            p: { xs: 2, sm: 3 },
            background: 'linear-gradient(135deg, #ffffff 0%, #fce7f3 100%)',
            border: '2px solid #fbcfe8',
            transition: 'transform 0.2s ease, box-shadow 0.2s ease',
            '&:hover': {
              transform: 'translateY(-4px)',
              boxShadow: '0 12px 24px rgba(236, 72, 153, 0.15)',
            },
          }}>
            <Typography variant="h6" sx={{
              background: 'linear-gradient(135deg, #ec4899 0%, #db2777 100%)',
              WebkitBackgroundClip: 'text',
              WebkitTextFillColor: 'transparent',
              fontWeight: 700,
              mb: 2,
            }}>
              Budget Overview
            </Typography>
            <Stack spacing={2}>
              <BudgetProgress spent={budget?.totalSpent || 0} limit={budget?.totalLimit || 1} label="Overall Budget" />
              {budget?.categoryBudgets.map((categoryBudget) => (
                <BudgetProgress
                  key={categoryBudget.category._id}
                  spent={categoryBudget.spent}
                  limit={categoryBudget.limit}
                  label={categoryBudget.category.name}
                />
              ))}
            </Stack>
          </Paper>
        </Grid>
        <Grid item xs={12} md={4}>
          <Paper sx={{
            p: { xs: 2, sm: 3 },
            background: 'linear-gradient(135deg, #ffffff 0%, #ede9fe 100%)',
            border: '2px solid #ddd6fe',
            transition: 'transform 0.2s ease, box-shadow 0.2s ease',
            '&:hover': {
              transform: 'translateY(-4px)',
              boxShadow: '0 12px 24px rgba(139, 92, 246, 0.15)',
            },
          }}>
            <Typography variant="h6" sx={{
              background: 'linear-gradient(135deg, #8b5cf6 0%, #7c3aed 100%)',
              WebkitBackgroundClip: 'text',
              WebkitTextFillColor: 'transparent',
              fontWeight: 700,
              mb: 2,
            }}>
              Quick Export
            </Typography>
            <Stack spacing={2}>
              <Button variant="contained" onClick={exportCsv} fullWidth>
                Export CSV
              </Button>
              <Button variant="outlined" onClick={exportExcel} fullWidth>
                Export Excel
              </Button>
              <Button variant="outlined" onClick={exportPdf} fullWidth>
                Export PDF
              </Button>
            </Stack>
          </Paper>
        </Grid>
      </Grid>
    </div>
  );
};

export default DashboardPage;
