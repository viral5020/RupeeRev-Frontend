import React from 'react';
import { Button, Grid, MenuItem, Paper, Stack, TextField } from '@mui/material';
import PageHeader from '../components/common/PageHeader';
import { useCategories } from '../hooks/useCategories';
import { useBudget } from '../hooks/useBudget';
import { saveBudget } from '../services/budgetService';
import { useSnackbar } from 'notistack';
import BudgetProgress from '../components/common/BudgetProgress';

const BudgetsPage: React.FC = () => {
  const now = new Date();
  const [month, setMonth] = React.useState(now.getMonth() + 1);
  const [year, setYear] = React.useState(now.getFullYear());
  const { data: categories } = useCategories();
  const { data: budget, refetch } = useBudget(month, year);
  const { enqueueSnackbar } = useSnackbar();
  const [totalLimit, setTotalLimit] = React.useState(budget?.totalLimit || 0);
  const [categoryBudgets, setCategoryBudgets] = React.useState<{ category: string; limit: number }[]>(
    budget?.categoryBudgets.map((cb) => ({ category: cb.category._id, limit: cb.limit })) || []
  );

  React.useEffect(() => {
    setTotalLimit(budget?.totalLimit || 0);
    setCategoryBudgets(budget?.categoryBudgets.map((cb) => ({ category: cb.category._id, limit: cb.limit })) || []);
  }, [budget]);

  const handleSave = async () => {
    await saveBudget({
      month,
      year,
      totalLimit,
      categoryBudgets,
    });
    enqueueSnackbar('Budget saved', { variant: 'success' });
    refetch();
  };

  return (
    <div>
      <PageHeader title="Budgets" />
      <Stack direction="row" spacing={2} sx={{ mb: 3 }}>
        <TextField select label="Month" value={month} onChange={(event) => setMonth(Number(event.target.value))}>
          {Array.from({ length: 12 }).map((_, index) => (
            <MenuItem key={index + 1} value={index + 1}>
              {index + 1}
            </MenuItem>
          ))}
        </TextField>
        <TextField label="Year" type="number" value={year} onChange={(event) => setYear(Number(event.target.value))} />
      </Stack>
      <Paper sx={{ p: 3, mb: 3 }}>
        <TextField
          label="Total budget"
          type="number"
          value={totalLimit}
          onChange={(event) => setTotalLimit(Number(event.target.value))}
          fullWidth
        />
        <BudgetProgress spent={budget?.totalSpent || 0} limit={totalLimit || 1} label="Overall budget" />
      </Paper>
      <Grid container spacing={2}>
        {categories?.map((category) => {
          const entry = categoryBudgets.find((cb) => cb.category === category._id);
          return (
            <Grid item xs={12} md={4} key={category._id}>
              <Paper sx={{ p: 2 }}>
                <Stack spacing={1}>
                  <strong>
                    {category.icon} {category.name}
                  </strong>
                  <TextField
                    label="Budget limit"
                    type="number"
                    value={entry?.limit || 0}
                    onChange={(event) =>
                      setCategoryBudgets((prev) => {
                        const next = prev.filter((cb) => cb.category !== category._id);
                        next.push({ category: category._id, limit: Number(event.target.value) });
                        return next;
                      })
                    }
                  />
                  {budget?.categoryBudgets
                    .filter((cb) => cb.category._id === category._id)
                    .map((cb) => (
                      <BudgetProgress key={cb.category._id} spent={cb.spent} limit={cb.limit} label={`${category.name} spend`} />
                    ))}
                </Stack>
              </Paper>
            </Grid>
          );
        })}
      </Grid>
      <Button variant="contained" sx={{ mt: 3 }} onClick={handleSave}>
        Save Budgets
      </Button>
    </div>
  );
};

export default BudgetsPage;

