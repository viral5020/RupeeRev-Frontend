import React from 'react';
import { Grid, Paper, Typography } from '@mui/material';
import PageHeader from '../components/common/PageHeader';
import CategoryPieChart from '../components/analytics/CategoryPieChart';
import MonthlyBarChart from '../components/analytics/MonthlyBarChart';
import IncomeExpenseLine from '../components/analytics/IncomeExpenseLine';
import { useCategoryStats, useMonthlyStats } from '../hooks/useStats';

const AnalyticsPage: React.FC = () => {
  const { data: categoryStats } = useCategoryStats({});
  const { data: monthlyStats } = useMonthlyStats();
  const chartData = [
    { name: 'Current', income: monthlyStats?.totalIncome || 0, expense: monthlyStats?.totalExpense || 0 },
  ];

  return (
    <div>
      <PageHeader title='Analytics' />
      <Grid container spacing={3}>
        <Grid item xs={12} md={6}>
          <Paper sx={{ p: 3 }}>
            <Typography variant='h6'>Category distribution</Typography>
            <CategoryPieChart data={categoryStats || []} />
          </Paper>
        </Grid>
        <Grid item xs={12} md={6}>
          <Paper sx={{ p: 3 }}>
            <Typography variant='h6'>Monthly comparison</Typography>
            <MonthlyBarChart data={chartData} />
          </Paper>
        </Grid>
        <Grid item xs={12}>
          <Paper sx={{ p: 3 }}>
            <Typography variant='h6'>Income vs expense trend</Typography>
            <IncomeExpenseLine data={chartData} />
          </Paper>
        </Grid>
      </Grid>
    </div>
  );
};

export default AnalyticsPage;

