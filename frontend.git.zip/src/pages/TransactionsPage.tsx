import React from 'react';
import { Grid, Pagination, Stack, Button, Dialog, DialogContent, DialogTitle, TextField } from '@mui/material';
import { useQueryClient } from '@tanstack/react-query';
import PageHeader from '../components/common/PageHeader';
import TransactionFilters from '../components/filters/TransactionFilters';
import TransactionCard from '../components/transactions/TransactionCard';
import TransactionForm, { TransactionFormValues } from '../components/transactions/TransactionForm';
import { useTransactions } from '../hooks/useTransactions';
import { useFilters } from '../context/FilterContext';
import { createTransaction, deleteTransaction, updateTransaction } from '../services/transactionService';
import { Transaction } from '../types';
import { useSnackbar } from 'notistack';

const TransactionsPage: React.FC = () => {
  const { data, isLoading } = useTransactions();
  const { filters, setFilters } = useFilters();
  const [open, setOpen] = React.useState(false);
  const [selected, setSelected] = React.useState<Transaction | null>(null);
  const { enqueueSnackbar } = useSnackbar();
  const queryClient = useQueryClient();
  const [confirmOpen, setConfirmOpen] = React.useState(false);

  const handleOpen = (transaction?: Transaction) => {
    setSelected(transaction ?? null);
    setOpen(true);
  };

  const handleSubmit = async (values: TransactionFormValues, attachments: FileList | null) => {
    const formData = new FormData();
    Object.entries(values).forEach(([key, value]) => {
      if (value === undefined || value === null) return;
      if (key === 'recurrenceEnabled' || key === 'frequency') return;
      formData.append(key, String(value));
    });
    if (values.recurrenceEnabled && values.frequency) {
      formData.append(
        'recurrence',
        JSON.stringify({
          frequency: values.frequency,
        })
      );
    }
    if (attachments) {
      Array.from(attachments).forEach((file) => formData.append('attachments', file));
    }
    if (selected) {
      await updateTransaction(selected._id, formData);
      enqueueSnackbar('Transaction updated', { variant: 'success' });
    } else {
      await createTransaction(formData);
      enqueueSnackbar('Transaction created', { variant: 'success' });
    }
    setOpen(false);
    queryClient.invalidateQueries({ queryKey: ['transactions'] });
  };

  const handleDelete = async () => {
    if (selected) {
      await deleteTransaction(selected._id);
      enqueueSnackbar('Transaction deleted', { variant: 'info' });
      setConfirmOpen(false);
      setSelected(null);
      queryClient.invalidateQueries({ queryKey: ['transactions'] });
    }
  };

  return (
    <div>
      <PageHeader title="Transactions" actionLabel="Add Transaction" onAction={() => handleOpen()} />
      <TransactionFilters />
      {isLoading ? (
        <div>Loading...</div>
      ) : (
        <Grid container spacing={2}>
          {data?.docs.map((transaction) => (
            <Grid item xs={12} md={6} key={transaction._id}>
              <TransactionCard
                transaction={transaction}
                onEdit={() => handleOpen(transaction)}
                onDelete={(tx) => {
                  setSelected(tx);
                  setConfirmOpen(true);
                }}
              />
            </Grid>
          ))}
        </Grid>
      )}
      <Stack alignItems="center" sx={{ mt: 3 }}>
      <Pagination count={data?.totalPages || 1} page={filters.page || 1} onChange={(_event, page) => setFilters({ page })} color="primary" />
      </Stack>
      <TransactionForm
        open={open}
        initialValues={
          selected
            ? {
                title: selected.title,
                amount: selected.amount,
                type: selected.type,
                category: selected.category._id,
                account: selected.account._id,
                date: selected.date.slice(0, 10),
                notes: selected.notes,
              }
            : undefined
        }
        onClose={() => {
          setSelected(null);
          setOpen(false);
        }}
        onSubmit={handleSubmit}
      />
      <Dialog
        open={confirmOpen}
        onClose={() => {
          setConfirmOpen(false);
          setSelected(null);
        }}
      >
        <DialogTitle>Confirm delete</DialogTitle>
        <DialogContent>
          <TextField value={selected?.title || ''} fullWidth disabled />
          <Stack direction="row" spacing={2} sx={{ mt: 2 }}>
            <Button
              onClick={() => {
                setConfirmOpen(false);
                setSelected(null);
              }}
            >
              Cancel
            </Button>
            <Button
              variant="contained"
              color="error"
              onClick={async () => {
                await handleDelete();
                setSelected(null);
              }}
            >
              Delete
            </Button>
          </Stack>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default TransactionsPage;

