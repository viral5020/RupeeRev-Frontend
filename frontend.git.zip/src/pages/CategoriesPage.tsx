import React from 'react';
import { Button, Dialog, DialogActions, DialogContent, DialogTitle, Grid, MenuItem, Stack, TextField } from '@mui/material';
import PageHeader from '../components/common/PageHeader';
import { useCategories } from '../hooks/useCategories';
import { createCategory, deleteCategory, updateCategory } from '../services/categoryService';
import { useSnackbar } from 'notistack';

const CategoriesPage: React.FC = () => {
  const { data, refetch } = useCategories();
  const [open, setOpen] = React.useState(false);
  const [form, setForm] = React.useState<{ name: string; type: 'income' | 'expense'; color: string; icon: string; id: string }>({
    name: '',
    type: 'expense',
    color: '#000000',
    icon: '🧾',
    id: '',
  });
  const { enqueueSnackbar } = useSnackbar();

  const handleSave = async () => {
    if (form.id) {
      await updateCategory(form.id, form);
      enqueueSnackbar('Category updated', { variant: 'success' });
    } else {
      await createCategory(form);
      enqueueSnackbar('Category created', { variant: 'success' });
    }
    setOpen(false);
    await refetch();
  };

  const handleDelete = async (id: string) => {
    await deleteCategory(id);
    enqueueSnackbar('Category deleted', { variant: 'info' });
    refetch();
  };

  return (
    <div>
      <PageHeader
        title="Categories"
        actionLabel="Add Category"
        onAction={() => {
          setForm({ name: '', type: 'expense', color: '#000000', icon: '🧾', id: '' });
          setOpen(true);
        }}
      />
      <Grid container spacing={2}>
        {data?.map((category) => (
          <Grid item xs={12} md={4} key={category._id}>
            <Stack
              sx={{
                p: 2,
                borderRadius: 2,
                border: '1px solid #e5e7eb',
                background: '#fff',
              }}
              spacing={1}
            >
              <Stack direction="row" justifyContent="space-between">
                <strong>{category.icon}</strong>
                <Stack direction="row" spacing={1}>
                  <Button
                    size="small"
                    onClick={() => {
                      setForm({ ...category, id: category._id });
                      setOpen(true);
                    }}
                  >
                    Edit
                  </Button>
                  {!category.isDefault && (
                    <Button color="error" size="small" onClick={() => handleDelete(category._id)}>
                      Delete
                    </Button>
                  )}
                </Stack>
              </Stack>
              <strong>{category.name}</strong>
              <span>{category.type}</span>
            </Stack>
          </Grid>
        ))}
      </Grid>
      <Dialog open={open} onClose={() => setOpen(false)}>
        <DialogTitle>{form.id ? 'Edit Category' : 'New Category'}</DialogTitle>
        <DialogContent sx={{ display: 'flex', flexDirection: 'column', gap: 2, mt: 1 }}>
          <TextField label="Name" value={form.name} onChange={(event) => setForm((prev) => ({ ...prev, name: event.target.value }))} />
          <TextField
            select
            label="Type"
            value={form.type}
            onChange={(event) => setForm((prev) => ({ ...prev, type: event.target.value as 'income' | 'expense' }))}
          >
            <MenuItem value="income">Income</MenuItem>
            <MenuItem value="expense">Expense</MenuItem>
          </TextField>
          <TextField
            label="Color"
            type="color"
            value={form.color}
            onChange={(event) => setForm((prev) => ({ ...prev, color: event.target.value }))}
          />
          <TextField label="Icon" value={form.icon} onChange={(event) => setForm((prev) => ({ ...prev, icon: event.target.value }))} />
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setOpen(false)}>Cancel</Button>
          <Button onClick={handleSave} variant="contained">
            Save
          </Button>
        </DialogActions>
      </Dialog>
    </div>
  );
};

export default CategoriesPage;

