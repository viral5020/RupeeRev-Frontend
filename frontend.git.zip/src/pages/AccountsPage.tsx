import React from 'react';
import { Button, Dialog, DialogActions, DialogContent, DialogTitle, Grid, MenuItem, TextField } from '@mui/material';
import PageHeader from '../components/common/PageHeader';
import { useAccounts } from '../hooks/useAccounts';
import { createAccount, deleteAccount } from '../services/accountService';
import { useSnackbar } from 'notistack';

const AccountsPage: React.FC = () => {
  const { data, refetch } = useAccounts();
  const [open, setOpen] = React.useState(false);
  const [form, setForm] = React.useState<{ name: string; type: 'bank' | 'cash' | 'wallet'; initialBalance: number; currency: string }>({
    name: '',
    type: 'bank',
    initialBalance: 0,
    currency: 'USD',
  });
  const { enqueueSnackbar } = useSnackbar();

  const handleSave = async () => {
    await createAccount({ ...form, initialBalance: Number(form.initialBalance) });
    enqueueSnackbar('Account created', { variant: 'success' });
    refetch();
    setOpen(false);
  };

  const handleDelete = async (id: string) => {
    await deleteAccount(id);
    enqueueSnackbar('Account deleted', { variant: 'info' });
    refetch();
  };

  return (
    <div>
      <PageHeader title="Accounts" actionLabel="Add Account" onAction={() => setOpen(true)} />
      <Grid container spacing={2}>
        {data?.map((account) => (
          <Grid item xs={12} md={4} key={account._id}>
            <div style={{ padding: 16, borderRadius: 12, background: '#fff', border: '1px solid #e5e7eb' }}>
              <strong>{account.name}</strong>
              <p>{account.type}</p>
              <p>Balance: {account.currentBalance.toLocaleString()}</p>
              <Button color="error" size="small" onClick={() => handleDelete(account._id)}>
                Delete
              </Button>
            </div>
          </Grid>
        ))}
      </Grid>
      <Dialog open={open} onClose={() => setOpen(false)}>
        <DialogTitle>New Account</DialogTitle>
        <DialogContent sx={{ display: 'flex', flexDirection: 'column', gap: 2, mt: 1 }}>
          <TextField label="Name" value={form.name} onChange={(event) => setForm((prev) => ({ ...prev, name: event.target.value }))} />
          <TextField
            select
            label="Type"
            value={form.type}
            onChange={(event) => setForm((prev) => ({ ...prev, type: event.target.value as 'bank' | 'cash' | 'wallet' }))}
          >
            <MenuItem value="bank">Bank</MenuItem>
            <MenuItem value="cash">Cash</MenuItem>
            <MenuItem value="wallet">Wallet</MenuItem>
          </TextField>
          <TextField
            label="Initial Balance"
            type="number"
            value={form.initialBalance}
            onChange={(event) => setForm((prev) => ({ ...prev, initialBalance: Number(event.target.value) }))}
          />
          <TextField label="Currency" value={form.currency} onChange={(event) => setForm((prev) => ({ ...prev, currency: event.target.value }))} />
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setOpen(false)}>Cancel</Button>
          <Button onClick={handleSave} variant="contained">
            Save
          </Button>
        </DialogActions>
      </Dialog>
    </div>
  );
};

export default AccountsPage;

