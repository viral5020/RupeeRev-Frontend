import React from 'react';
import { Box, Button, Paper, Stack, TextField, Typography } from '@mui/material';
import { useAuth } from '../../context/AuthContext';

const LoginPage: React.FC = () => {
  const { login, register, loading } = useAuth();
  const [mode, setMode] = React.useState<'login' | 'register'>('login');
  const [form, setForm] = React.useState({ name: '', email: '', password: '' });

  const handleSubmit = async (event: React.FormEvent) => {
    event.preventDefault();
    if (mode === 'login') {
      await login(form.email, form.password);
    } else {
      await register(form.name, form.email, form.password);
    }
  };

  return (
    <Box sx={{ minHeight: '100vh', display: 'flex', alignItems: 'center', justifyContent: 'center', background: 'linear-gradient(135deg,#e0e7ff,#f8fafc)' }}>
      <Paper sx={{ p: 4, width: 400 }} component="form" onSubmit={handleSubmit}>
        <Typography variant="h5" sx={{ mb: 2 }}>
          {mode === 'login' ? 'Sign in' : 'Create account'}
        </Typography>
        <Stack spacing={2}>
          {mode === 'register' && (
            <TextField label="Name" value={form.name} onChange={(event) => setForm((prev) => ({ ...prev, name: event.target.value }))} />
          )}
          <TextField label="Email" type="email" value={form.email} onChange={(event) => setForm((prev) => ({ ...prev, email: event.target.value }))} />
          <TextField label="Password" type="password" value={form.password} onChange={(event) => setForm((prev) => ({ ...prev, password: event.target.value }))} />
          <Button type="submit" variant="contained" disabled={loading}>
            {mode === 'login' ? 'Login' : 'Register'}
          </Button>
          <Button variant="text" onClick={() => {
            setMode(mode === 'login' ? 'register' : 'login');
            setForm({ name: '', email: '', password: '' });
          }}>
            {mode === 'login' ? 'No account? Register' : 'Have an account? Login'}
          </Button>
        </Stack>
      </Paper>
    </Box>
  );
};

export default LoginPage;

