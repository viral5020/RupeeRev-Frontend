import React from 'react';
import AppRouter from './router/AppRouter';
import './App.css';

import { ThemeProvider, CssBaseline } from '@mui/material';
import theme from './theme';

const App: React.FC = () => (
    <ThemeProvider theme={theme}>
        <CssBaseline />
        <AppRouter />
    </ThemeProvider>
);

export default App;

