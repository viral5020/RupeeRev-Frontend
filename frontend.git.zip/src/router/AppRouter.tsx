import React from 'react';
import { Navigate, Route, Routes } from 'react-router-dom';
import DashboardPage from '../pages/DashboardPage';
import TransactionsPage from '../pages/TransactionsPage';
import CategoriesPage from '../pages/CategoriesPage';
import AccountsPage from '../pages/AccountsPage';
import BudgetsPage from '../pages/BudgetsPage';
import AnalyticsPage from '../pages/AnalyticsPage';
import InvestmentsPage from '../pages/InvestmentsPage';
import GoalsPage from '../pages/GoalsPage';
import StocksPage from '../pages/StocksPage';
import SalaryPlannerPage from '../pages/SalaryPlannerPage';
import AppLayout from '../components/layout/AppLayout';
import LoginPage from '../pages/Auth/LoginPage';
import { useAuth } from '../context/AuthContext';

const PrivateRoutes: React.FC = () => (
  <AppLayout>
    <Routes>
      <Route path="/" element={<DashboardPage />} />
      <Route path="/transactions" element={<TransactionsPage />} />
      <Route path="/categories" element={<CategoriesPage />} />
      <Route path="/accounts" element={<AccountsPage />} />
      <Route path="/budgets" element={<BudgetsPage />} />
      <Route path="/analytics" element={<AnalyticsPage />} />
      <Route path="/goals" element={<GoalsPage />} />
      <Route path="/investments" element={<InvestmentsPage />} />
      <Route path="/stocks" element={<StocksPage />} />
      <Route path="/salary-planner" element={<SalaryPlannerPage />} />
      <Route path="*" element={<Navigate to="/" replace />} />
    </Routes>
  </AppLayout>
);

const AppRouter: React.FC = () => {
  const { user } = useAuth();

  if (!user) {
    return <LoginPage />;
  }

  return <PrivateRoutes />;
};

export default AppRouter;
